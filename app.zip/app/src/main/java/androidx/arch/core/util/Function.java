package androidx.arch.core.util;

/* loaded from: classes.dex */
public interface Function<I, O> {
    O apply(I i);
}
