package androidx.coordinatorlayout;

/* loaded from: classes.dex */
public final class R {

    public static final class attr {
        public static int alpha = 0x7f030034;
        public static int coordinatorLayoutStyle = 0x7f030152;
        public static int font = 0x7f030213;
        public static int fontProviderAuthority = 0x7f030215;
        public static int fontProviderCerts = 0x7f030216;
        public static int fontProviderFetchStrategy = 0x7f030217;
        public static int fontProviderFetchTimeout = 0x7f030218;
        public static int fontProviderPackage = 0x7f030219;
        public static int fontProviderQuery = 0x7f03021a;
        public static int fontStyle = 0x7f03021c;
        public static int fontVariationSettings = 0x7f03021d;
        public static int fontWeight = 0x7f03021e;
        public static int keylines = 0x7f03027f;
        public static int layout_anchor = 0x7f03028b;
        public static int layout_anchorGravity = 0x7f03028c;
        public static int layout_behavior = 0x7f03028d;
        public static int layout_dodgeInsetEdges = 0x7f0302be;
        public static int layout_insetEdge = 0x7f0302c8;
        public static int layout_keyline = 0x7f0302c9;
        public static int statusBarBackground = 0x7f03042c;
        public static int ttcIndex = 0x7f0304f8;

        private attr() {
        }
    }

    public static final class color {
        public static int notification_action_color_filter = 0x7f0502ce;
        public static int notification_icon_bg_color = 0x7f0502cf;
        public static int ripple_material_light = 0x7f0502dd;
        public static int secondary_text_default_material_light = 0x7f0502df;

        private color() {
        }
    }

    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 0x7f060056;
        public static int compat_button_inset_vertical_material = 0x7f060057;
        public static int compat_button_padding_horizontal_material = 0x7f060058;
        public static int compat_button_padding_vertical_material = 0x7f060059;
        public static int compat_control_corner_material = 0x7f06005a;
        public static int compat_notification_large_icon_max_height = 0x7f06005b;
        public static int compat_notification_large_icon_max_width = 0x7f06005c;
        public static int notification_action_icon_size = 0x7f060304;
        public static int notification_action_text_size = 0x7f060305;
        public static int notification_big_circle_margin = 0x7f060306;
        public static int notification_content_margin_start = 0x7f060307;
        public static int notification_large_icon_height = 0x7f060308;
        public static int notification_large_icon_width = 0x7f060309;
        public static int notification_main_column_padding_top = 0x7f06030a;
        public static int notification_media_narrow_margin = 0x7f06030b;
        public static int notification_right_icon_size = 0x7f06030c;
        public static int notification_right_side_padding_top = 0x7f06030d;
        public static int notification_small_icon_background_padding = 0x7f06030e;
        public static int notification_small_icon_size_as_large = 0x7f06030f;
        public static int notification_subtext_size = 0x7f060310;
        public static int notification_top_pad = 0x7f060311;
        public static int notification_top_pad_large_text = 0x7f060312;

        private dimen() {
        }
    }

    public static final class drawable {
        public static int notification_action_background = 0x7f0700d6;
        public static int notification_bg = 0x7f0700d7;
        public static int notification_bg_low = 0x7f0700d8;
        public static int notification_bg_low_normal = 0x7f0700d9;
        public static int notification_bg_low_pressed = 0x7f0700da;
        public static int notification_bg_normal = 0x7f0700db;
        public static int notification_bg_normal_pressed = 0x7f0700dc;
        public static int notification_icon_background = 0x7f0700dd;
        public static int notification_template_icon_bg = 0x7f0700de;
        public static int notification_template_icon_low_bg = 0x7f0700df;
        public static int notification_tile_bg = 0x7f0700e0;
        public static int notify_panel_notification_icon_bg = 0x7f0700e1;

        private drawable() {
        }
    }

    public static final class id {
        public static int accessibility_action_clickable_span = 0x7f08000f;
        public static int accessibility_custom_action_0 = 0x7f080010;
        public static int accessibility_custom_action_1 = 0x7f080011;
        public static int accessibility_custom_action_10 = 0x7f080012;
        public static int accessibility_custom_action_11 = 0x7f080013;
        public static int accessibility_custom_action_12 = 0x7f080014;
        public static int accessibility_custom_action_13 = 0x7f080015;
        public static int accessibility_custom_action_14 = 0x7f080016;
        public static int accessibility_custom_action_15 = 0x7f080017;
        public static int accessibility_custom_action_16 = 0x7f080018;
        public static int accessibility_custom_action_17 = 0x7f080019;
        public static int accessibility_custom_action_18 = 0x7f08001a;
        public static int accessibility_custom_action_19 = 0x7f08001b;
        public static int accessibility_custom_action_2 = 0x7f08001c;
        public static int accessibility_custom_action_20 = 0x7f08001d;
        public static int accessibility_custom_action_21 = 0x7f08001e;
        public static int accessibility_custom_action_22 = 0x7f08001f;
        public static int accessibility_custom_action_23 = 0x7f080020;
        public static int accessibility_custom_action_24 = 0x7f080021;
        public static int accessibility_custom_action_25 = 0x7f080022;
        public static int accessibility_custom_action_26 = 0x7f080023;
        public static int accessibility_custom_action_27 = 0x7f080024;
        public static int accessibility_custom_action_28 = 0x7f080025;
        public static int accessibility_custom_action_29 = 0x7f080026;
        public static int accessibility_custom_action_3 = 0x7f080027;
        public static int accessibility_custom_action_30 = 0x7f080028;
        public static int accessibility_custom_action_31 = 0x7f080029;
        public static int accessibility_custom_action_4 = 0x7f08002a;
        public static int accessibility_custom_action_5 = 0x7f08002b;
        public static int accessibility_custom_action_6 = 0x7f08002c;
        public static int accessibility_custom_action_7 = 0x7f08002d;
        public static int accessibility_custom_action_8 = 0x7f08002e;
        public static int accessibility_custom_action_9 = 0x7f08002f;
        public static int action_container = 0x7f08003a;
        public static int action_divider = 0x7f08003c;
        public static int action_image = 0x7f08003d;
        public static int action_text = 0x7f080043;
        public static int actions = 0x7f080044;
        public static int async = 0x7f080053;
        public static int blocking = 0x7f08005d;
        public static int bottom = 0x7f08005e;
        public static int chronometer = 0x7f080077;
        public static int dialog_button = 0x7f08009b;
        public static int end = 0x7f0800b4;
        public static int forever = 0x7f0800cc;
        public static int icon = 0x7f0800de;
        public static int icon_group = 0x7f0800e0;
        public static int info = 0x7f0800e8;
        public static int italic = 0x7f0800eb;
        public static int left = 0x7f0800f1;
        public static int line1 = 0x7f0800f4;
        public static int line3 = 0x7f0800f5;
        public static int none = 0x7f080143;
        public static int normal = 0x7f080144;
        public static int notification_background = 0x7f080146;
        public static int notification_main_column = 0x7f080147;
        public static int notification_main_column_container = 0x7f080148;
        public static int right = 0x7f080179;
        public static int right_icon = 0x7f08017b;
        public static int right_side = 0x7f08017c;
        public static int start = 0x7f0801b6;
        public static int tag_accessibility_actions = 0x7f0801c4;
        public static int tag_accessibility_clickable_spans = 0x7f0801c5;
        public static int tag_accessibility_heading = 0x7f0801c6;
        public static int tag_accessibility_pane_title = 0x7f0801c7;
        public static int tag_screen_reader_focusable = 0x7f0801cb;
        public static int tag_transition_group = 0x7f0801cd;
        public static int tag_unhandled_key_event_manager = 0x7f0801ce;
        public static int tag_unhandled_key_listeners = 0x7f0801cf;
        public static int text = 0x7f0801d1;
        public static int text2 = 0x7f0801d2;
        public static int time = 0x7f0801e2;
        public static int title = 0x7f0801e3;
        public static int top = 0x7f0801e7;

        private id() {
        }
    }

    public static final class integer {
        public static int status_bar_notification_info_maxnum = 0x7f090045;

        private integer() {
        }
    }

    public static final class layout {
        public static int custom_dialog = 0x7f0b001e;
        public static int notification_action = 0x7f0b0064;
        public static int notification_action_tombstone = 0x7f0b0065;
        public static int notification_template_custom_big = 0x7f0b0066;
        public static int notification_template_icon_group = 0x7f0b0067;
        public static int notification_template_part_chronometer = 0x7f0b0068;
        public static int notification_template_part_time = 0x7f0b0069;

        private layout() {
        }
    }

    public static final class string {
        public static int status_bar_notification_info_overflow = 0x7f1000a3;

        private string() {
        }
    }

    public static final class style {
        public static int TextAppearance_Compat_Notification = 0x7f1101e3;
        public static int TextAppearance_Compat_Notification_Info = 0x7f1101e4;
        public static int TextAppearance_Compat_Notification_Line2 = 0x7f1101e5;
        public static int TextAppearance_Compat_Notification_Time = 0x7f1101e6;
        public static int TextAppearance_Compat_Notification_Title = 0x7f1101e7;
        public static int Widget_Compat_NotificationActionContainer = 0x7f11034d;
        public static int Widget_Compat_NotificationActionText = 0x7f11034e;
        public static int Widget_Support_CoordinatorLayout = 0x7f11047b;

        private style() {
        }
    }

    public static final class styleable {
        public static int ColorStateListItem_alpha = 0x00000003;
        public static int ColorStateListItem_android_alpha = 0x00000001;
        public static int ColorStateListItem_android_color = 0x00000000;
        public static int ColorStateListItem_android_lStar = 0x00000002;
        public static int ColorStateListItem_lStar = 0x00000004;
        public static int CoordinatorLayout_Layout_android_layout_gravity = 0x00000000;
        public static int CoordinatorLayout_Layout_layout_anchor = 0x00000001;
        public static int CoordinatorLayout_Layout_layout_anchorGravity = 0x00000002;
        public static int CoordinatorLayout_Layout_layout_behavior = 0x00000003;
        public static int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 0x00000004;
        public static int CoordinatorLayout_Layout_layout_insetEdge = 0x00000005;
        public static int CoordinatorLayout_Layout_layout_keyline = 0x00000006;
        public static int CoordinatorLayout_keylines = 0x00000000;
        public static int CoordinatorLayout_statusBarBackground = 0x00000001;
        public static int FontFamilyFont_android_font = 0x00000000;
        public static int FontFamilyFont_android_fontStyle = 0x00000002;
        public static int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static int FontFamilyFont_android_fontWeight = 0x00000001;
        public static int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static int FontFamilyFont_font = 0x00000005;
        public static int FontFamilyFont_fontStyle = 0x00000006;
        public static int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static int FontFamilyFont_fontWeight = 0x00000008;
        public static int FontFamilyFont_ttcIndex = 0x00000009;
        public static int FontFamily_fontProviderAuthority = 0x00000000;
        public static int FontFamily_fontProviderCerts = 0x00000001;
        public static int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static int FontFamily_fontProviderPackage = 0x00000004;
        public static int FontFamily_fontProviderQuery = 0x00000005;
        public static int FontFamily_fontProviderSystemFontFamily = 0x00000006;
        public static int GradientColorItem_android_color = 0x00000000;
        public static int GradientColorItem_android_offset = 0x00000001;
        public static int GradientColor_android_centerColor = 0x00000007;
        public static int GradientColor_android_centerX = 0x00000003;
        public static int GradientColor_android_centerY = 0x00000004;
        public static int GradientColor_android_endColor = 0x00000001;
        public static int GradientColor_android_endX = 0x0000000a;
        public static int GradientColor_android_endY = 0x0000000b;
        public static int GradientColor_android_gradientRadius = 0x00000005;
        public static int GradientColor_android_startColor = 0x00000000;
        public static int GradientColor_android_startX = 0x00000008;
        public static int GradientColor_android_startY = 0x00000009;
        public static int GradientColor_android_tileMode = 0x00000006;
        public static int GradientColor_android_type = 0x00000002;
        public static int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, com.entropy.patcher.R.attr.alpha, com.entropy.patcher.R.attr.lStar};
        public static int[] CoordinatorLayout = {com.entropy.patcher.R.attr.keylines, com.entropy.patcher.R.attr.statusBarBackground};
        public static int[] CoordinatorLayout_Layout = {android.R.attr.layout_gravity, com.entropy.patcher.R.attr.layout_anchor, com.entropy.patcher.R.attr.layout_anchorGravity, com.entropy.patcher.R.attr.layout_behavior, com.entropy.patcher.R.attr.layout_dodgeInsetEdges, com.entropy.patcher.R.attr.layout_insetEdge, com.entropy.patcher.R.attr.layout_keyline};
        public static int[] FontFamily = {com.entropy.patcher.R.attr.fontProviderAuthority, com.entropy.patcher.R.attr.fontProviderCerts, com.entropy.patcher.R.attr.fontProviderFetchStrategy, com.entropy.patcher.R.attr.fontProviderFetchTimeout, com.entropy.patcher.R.attr.fontProviderPackage, com.entropy.patcher.R.attr.fontProviderQuery, com.entropy.patcher.R.attr.fontProviderSystemFontFamily};
        public static int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, com.entropy.patcher.R.attr.font, com.entropy.patcher.R.attr.fontStyle, com.entropy.patcher.R.attr.fontVariationSettings, com.entropy.patcher.R.attr.fontWeight, com.entropy.patcher.R.attr.ttcIndex};
        public static int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private R() {
    }
}
