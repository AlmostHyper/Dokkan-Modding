package androidx.core.app;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes.dex */
public final /* synthetic */ class JobIntentService$JobServiceEngineImpl$$ExternalSyntheticApiModelOutline0 {
}
