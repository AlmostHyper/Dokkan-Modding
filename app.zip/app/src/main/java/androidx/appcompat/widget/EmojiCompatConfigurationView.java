package androidx.appcompat.widget;

/* loaded from: classes.dex */
public interface EmojiCompatConfigurationView {
    boolean isEmojiCompatEnabled();

    void setEmojiCompatEnabled(boolean z);
}
