package androidx.appcompat.widget;

/* loaded from: classes.dex */
public interface WithHint {
    CharSequence getHint();
}
