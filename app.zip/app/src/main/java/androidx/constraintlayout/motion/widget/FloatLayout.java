package androidx.constraintlayout.motion.widget;

/* loaded from: classes.dex */
public interface FloatLayout {
    void layout(float lf, float tf, float rf, float bf);
}
