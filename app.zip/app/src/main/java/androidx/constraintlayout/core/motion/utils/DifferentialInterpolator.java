package androidx.constraintlayout.core.motion.utils;

/* loaded from: classes.dex */
public interface DifferentialInterpolator {
    float getInterpolation(float f);

    float getVelocity();
}
