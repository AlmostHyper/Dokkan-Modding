package androidx.constraintlayout.core.state.helpers;

import androidx.constraintlayout.core.widgets.ConstraintWidget;

/* loaded from: classes.dex */
public interface Facade {
    void apply();

    ConstraintWidget getConstraintWidget();
}
