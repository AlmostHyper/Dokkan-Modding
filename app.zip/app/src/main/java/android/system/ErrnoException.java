package android.system;

/* loaded from: classes.dex */
public final /* synthetic */ class ErrnoException extends Exception {
    static {
        throw new NoClassDefFoundError();
    }
}
